<?php

namespace App\Filament\Resources\LivraisonResource\Pages;

use App\Filament\Resources\LivraisonResource;
use Filament\Pages\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateLivraison extends CreateRecord
{
    protected static string $resource = LivraisonResource::class;
}
